<?php 
error_reporting(0);
//write a username (Temo by default)
$name = "PEKANBARU SPAMMERZ";


//write your scama password (12345 by default)
$password = "SAGARKONTOL";


//---------------------  Don't touch it !!! --------------------------------
$wrong_password_Error = " Your key is wrong .";
$help = "Check your email <b>( $your_email )</b> , to find your password .";
$permession_Error = "You have no permission to access to this file/page .";
$account_is_on = "panel.php?account=on";
$account_is_off = "panel.php?account=off";
//--------------------------------------------------------------------------
?>